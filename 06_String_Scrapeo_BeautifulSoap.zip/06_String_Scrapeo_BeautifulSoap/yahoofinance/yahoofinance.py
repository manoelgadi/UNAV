import xlwings as xw

def hello_xlwings():
    wb = xw.Book.caller()
    wb.sheets[0].range("A1").value = "Hello xlwings with Python 3!!!!"

@xw.func
def python_hello(name):
    return "hello {0}".format(name)

@xw.func
def python_version():
	import sys
	return(sys.version)

import pandas as pd
@xw.func
@xw.arg('x', pd.DataFrame, index=False)
@xw.ret(expand='table')
def python_describe(x):
   # x is a DataFrame, do something with it
   return x.describe()

import pandas_datareader.data as web   
import datetime

@xw.func
@xw.ret(expand='table')
def python_DataReader(ticker_symbol):
    end_date =   datetime.date.today() - datetime.timedelta(1)
    start_date = end_date - datetime.timedelta(days=5*365)
    df_stock = web.DataReader(ticker_symbol,'yahoo',start_date,end_date)
    return df_stock


import numpy as np
@xw.func
def python_Beta(ticker_symbol, ref_index):
    # Grab time series data for 5-year history for the stock
    # and for IBEX 35 Index

    edate =   datetime.date.today() - datetime.timedelta(1)
    sdate = edate - datetime.timedelta(days=5*365)
    
    df_stock = web.DataReader(ticker_symbol,'yahoo',sdate,edate)
    df_index = web.DataReader(ref_index,'yahoo',sdate,edate)
    
    # create a time-series of monthly data points
    df_stock = df_stock.resample('M').last()
    df_index = df_index.resample('M').last()
    
    df_stock['returns'] = df_stock['Adj Close']/ df_stock['Adj Close'].shift(1) -1
    df_stock = df_stock.dropna()
    df_index['returns'] = df_index['Adj Close']/ df_index['Adj Close'].shift(1) -1
    df_index = df_index.dropna()
    
    df = pd.DataFrame({'stock_returns' : df_stock['returns'],
                            'index_returns' : df_index['returns']},
                            index=df_stock.index)
    df = df.dropna()
    
    # reference - http://ci.columbia.edu/ci/premba_test/c0331/s7/s7_5.html
    def covariance(a, b):
        if len(a) != len(b):
            return
        a_mean = np.mean(a)
        b_mean = np.mean(b)
        sum = 0
        for i in range(0, len(a)):
            sum += ((a[i] - a_mean) * (b[i] - b_mean))
        return sum/(len(a)-1)
    
    
    #http://www.investopedia.com/ask/answers/070615/what-formula-calculating-beta.asp
    return covariance(df['stock_returns'],df['index_returns'])/covariance(df['index_returns'],df['index_returns'])


from bs4 import BeautifulSoup
import time
from random import randint
from urllib.request import urlopen

def safe_read_yahoo_finance_key_statistics(stock):
    ''' Function for safe requesting information from Yahoo Finance Key Statistics for a given stock. 
    If Yahoo fails to respond, it sleeps for random number of second between 1 to 12 seconds and then try again.
    The functions tries again up to 10 times! '''
    sourceCode = ''
    ntries = 0
    while (sourceCode == '') and (ntries < 10):
        try:
            sourceCode = str(urlopen('https://finance.yahoo.com/quote/'+stock+'/key-statistics?p='+stock).read())
            return(sourceCode)
        except:
            time.sleep(randint(1,12))
            print('Error reading Yahoo KS - number of tries=',ntries)
        finally:
            ntries += 1 

    return(sourceCode) 

@xw.func
@xw.ret(expand='table')
def python_scraping_yahoo_finance_key_statistics(stock):
    sourceCode = safe_read_yahoo_finance_key_statistics(stock)
    ## BEAUTIFUL SOUP SCRAPPING - START
    soup = BeautifulSoup(sourceCode, "html5lib") 
    table=soup.findAll('td') 
    key_list = []
    value_list = []        
    key_list.append('ScrapedName')
    value_list.append(soup.h1.text)
    for i in range(int(len(table)/2)): # On Yahoo the name of the data field appears in 0 and then the value in 1, then 2 and 3, and so on.
        key_list.append(table[2*i].text)
        value_list.append(table[2*i+1].text)
    df=pd.DataFrame(key_list,columns=['variable'])
    df['valor'] = value_list          
    ## BEAUTIFUL SOUP SCRAPPING - END
    return df	

